@extends('layouts.admin')

  @section('content')
      @include('partials.admin.cars._list-cars')
  @endsection
