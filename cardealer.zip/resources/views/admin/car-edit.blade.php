@extends('layouts.admin')

@section('content')
  @include('partials.admin.cars._add-car')
@endsection
