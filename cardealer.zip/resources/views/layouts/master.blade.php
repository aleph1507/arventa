@include('partials._head')
@include('partials._nav')
@include('partials._messages')

@yield('content')

<!-- Footer Section Start -->
@include('partials._footer')
<!-- Footer area End -->

<!-- Copyright Start  -->
@include('partials._copyright')
<!-- Copyright End -->

@include('partials._end')
