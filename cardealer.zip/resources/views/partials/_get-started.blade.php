<section class="great-started section">
<div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12">
          <div class="great-started-text text-center">
            <h4 class="wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">We Are Ready to Help You</h4>
            <h2 class="wow zoomIn" data-wow-duration="1000ms" data-wow-delay="100ms">Get the Best Solution for Your Business</h2>
            <a href="#" class="btn btn-common wow fadeInUp" data-wow-duration="3000ms" data-wow-delay="100ms">Get Started</a>
          </div>
      </div>
    </div>
  </div>
</section>
