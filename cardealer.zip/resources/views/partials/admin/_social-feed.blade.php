<div class="mb-0 mt-4">
  <i class="fa fa-newspaper-o"></i> News Feed</div>
