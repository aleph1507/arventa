<div class="container">
  <div class="row justify-content-md-center">
    <div class="col-md-10">
      <div class="carousel-slider owl-carousel owl-theme">
        <div class="item active">
          <div class="contents text-center">
            <img style="max-height: 400px;" src="https://www.cstatic-images.com/car-pictures/xl/usc70chc021e021001.png" alt="">
            <h1 class="wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">Car Salon</h1>
            <p class="lead  wow fadeIn" data-wow-duration="1000ms" data-wow-delay="400ms">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it.</p>
            <a href="#" class="btn btn-common wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">Read More</a>
            <a href="#" class="btn btn-border wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">Purchase</a>
            <div class="banner_bottom_btn wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="700ms">
              <a href="#about" class="js-target-scroll"><i class="icon-mouse"></i></a>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="contents text-center">
            <img style="max-height: 400px;" src="http://gulfcarsae.com/images/cars/1523416715202.png" alt="">
            <h1 class="wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">Car Salon</h1>
            <p class="lead  wow fadeIn" data-wow-duration="1000ms" data-wow-delay="400ms">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it.</p>
            <a href="#" class="btn btn-border wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">Get Started</a>
            <div class="banner_bottom_btn wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="700ms">
              <a href="#about" class="js-target-scroll"><i class="icon-mouse"></i></a>
            </div>
          </div>
        </div>
        <div class="item">
          <div class="contents text-center">
            <img style="max-height: 400px;" src="http://www.allwhitebackground.com/images/3/3125.png" alt="">
            <h1 class="wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">Car Salon</h1>
            <p class="lead  wow fadeIn" data-wow-duration="1000ms" data-wow-delay="400ms">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it.</p>
            <a href="#" class="btn btn-common wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">Read More</a>
            <a href="#" class="btn btn-border wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms">Purchase</a>
            <div class="banner_bottom_btn wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="700ms">
              <a href="#about" class="js-target-scroll"><i class="icon-mouse"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</header>
<!-- Header Section End -->
