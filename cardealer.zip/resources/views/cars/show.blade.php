@extends('layouts.master')

@section('content')

  @include('partials._about-car')

@endsection
