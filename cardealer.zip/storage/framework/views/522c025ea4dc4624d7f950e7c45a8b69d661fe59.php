<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> All Cars </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Motor Capacity</th>
            <th>Power</th>
            <th>Model</th>
            <th>Body Type</th>
            <th>Gearbox Type</th>
            <th>CO2 Emmision</th>
            <th>Top Speed</th>
            <th>Acceleration</th>
            <th>Location</th>
            <th>Color</th>
            <th>Edit</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>Motor Capacity</th>
            <th>Power</th>
            <th>Model</th>
            <th>Body Type</th>
            <th>Gearbox Type</th>
            <th>CO2 Emmision</th>
            <th>Top Speed</th>
            <th>Acceleration</th>
            <th>Location</th>
            <th>Color</th>
            <th>Edit</th>
          </tr>
        </tfoot>
        <tbody>
          <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($c->motorcapacity); ?></td>
              <td><?php echo e($c->power); ?></td>
              <td><?php echo e($c->model); ?></td>
              <td><?php echo e($c->bodytype); ?></td>
              <td><?php echo e($c->gearboxtype); ?></td>
              <td><?php echo e($c->co2emmision); ?></td>
              <td><?php echo e(isset($c->topspeed) ? $c->topspeed . 'km/h' : 'N/A'); ?></td>
              <td><?php echo e(isset($c->acceleration) ? '0-100 in ' . $c->acceleration . ' sec' : 'N/A'); ?></td>
              <td><?php echo e($c->location); ?></td>
              <td><?php echo e($c->color); ?></td>
              <td>
                <a href="<?php echo e(route('cars.edit', $c->id)); ?>" class="btn btn-outline-dark btn-sm">Edit</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted">All Cars List</div>
</div>
</div>
