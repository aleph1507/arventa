<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">
        <?php if(Request::is('admin')): ?>
          <?php echo "Add Car"; ?>
        <?php endif; ?>
        <?php if(Request::is('admin/cars/all')): ?>
          <?php echo "Manage Cars"; ?>
        <?php endif; ?>
        <?php if(Request::is('cars/edit/*')): ?>
          <?php echo "Edit Car"; ?>
        <?php endif; ?>
        <?php if(Request::is('admin/brands')): ?>
          <?php echo "Manage Brands"; ?>
        <?php endif; ?>
      </li>
    </ol>
