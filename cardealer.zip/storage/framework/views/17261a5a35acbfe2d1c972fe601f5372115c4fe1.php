<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
  <a class="navbar-brand" href="index.html">Admin Panel</a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
      <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
        <a class="nav-link" href="<?php echo e(url('/admin')); ?>">
          <i class="fa fa-fw fa-dashboard"></i>
          <span class="nav-link-text">Add car</span>
        </a>
      </li>
      <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
        <a class="nav-link" href="<?php echo e(route('cars.list')); ?>">
          <i class="fa fa-fw fa-area-chart"></i>
          <span class="nav-link-text">All Cars</span>
        </a>
      </li>
      <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
        <a class="nav-link" href="<?php echo e(route('brands.index')); ?>">
          <i class="fa fa-fw fa-table"></i>
          <span class="nav-link-text">Brands</span>
        </a>
      </li>
      
      
      
    </ul>
    <ul class="navbar-nav sidenav-toggler">
      <li class="nav-item">
        <a class="nav-link text-center" id="sidenavToggler">
          <i class="fa fa-fw fa-angle-left"></i>
        </a>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto">
      
      
      
      <li class="nav-item">
        <form action="<?php echo e('/logout'); ?>" method="post" id="logoutform">
          <?php echo e(csrf_field()); ?>

          <input type="submit" style="display:none;">
        </form>
        <a class="nav-link" onclick="document.getElementById('logoutform').submit()">
          <i class="fa fa-fw fa-sign-out"></i>Logout</a>
      </li>
    </ul>
  </div>
</nav>
