<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('partials.admin.brands._add-brand', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="container">
    <table class="table table-hover table-striped table-bordered table-dark" style="margin-top:5%;">
    <thead>
      <tr>
        <th scope="col">Brand Name</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <form action="<?php echo e(route('brands.update', $b->id)); ?>" method="post">
            <td>
              <input type="text" value="<?php echo e($b->name); ?>" name="name" class="form-control">
            </td>
            <td>
                <?php echo e(csrf_field()); ?>

                <input type="submit" class="btn btn-primary btn-sm" value="Change">
            </td>
          </form>
          <td>
            <form action="<?php echo e(route('brands.delete', $b->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="submit" class="btn btn-danger btn-sm" value="Delete">
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>