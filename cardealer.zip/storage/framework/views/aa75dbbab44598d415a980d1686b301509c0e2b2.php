<footer>
  <!-- Footer Area Start -->
  <section class="footer-Content">
    <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
      <h3 class="logo-title">Basic</h3>
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="widget">
            <div class="textwidget">
              <p>Lorem ipsum dolor sit amet, con sectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.Lorem ipsum dolor sit amet, con sectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
            </div>
            <form class="subscribe-box">
              <input placeholder="Your email" type="text">
              <input class="btn-system" value="Send" type="submit">
            </form>
          </div>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="widget">
            <h3 class="block-title">Links</h3>
            <ul class="menu">
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">Works</a></li>
              <li><a href="#">Pricing</a></li>
              <li><a href="#">Contact</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <div class="widget">
            <h3 class="block-title">Services</h3>
            <ul class="menu">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Graphics Design</a></li>
              <li><a href="#">Branding</a></li>
              <li><a href="#">UX Consulting</a></li>
              <li><a href="#">Mobile Apps</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="widget">
            <h3 class="block-title">Flicker Gallery</h3>
            <ul class="featured-list">
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img1.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img2.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img3.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img4.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img5.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img6.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img7.jpg')); ?>"></a>
              </li>
              <li>
                <a href="#"><img alt="" src="<?php echo e(asset('img/featured/img8.jpg')); ?>"></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
