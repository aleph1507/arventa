  <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._header-carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div style="margin-top:20%; color:#666;" class="container car-gallery">
      <?php $car_count=0; $first=true; ?>
      <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($car_count % 3 == 0): ?>
          <?php if($first == false): ?>
            </div>
          <?php endif; ?>
          <?php $first = false; ?>
          <div class="card-deck">
        <?php endif; ?>
        <div class="card car-card">
          <img src="<?php echo e(asset('images/cars/' . $car->featuredimage)); ?>" alt="<?php echo e($car->model); ?>" class="card-img-top">
          <div class="card-body">
            <h1 class="card-title"><?php echo e($car->model); ?></h1>
            <p class="card-text">Motor Capacity: <?php echo e($car->motorcapacity); ?></p>
            <p class="card-text">Power: <?php echo e($car->power); ?></p>
            <p class="card-text">Body Type: <?php echo e($car->bodytype); ?></p>
            <p class="card-text">Gearbox Type: <?php echo e($car->gearboxtype); ?></p>
            <p class="card-text">CO2 Emmision: <?php echo e($car->co2emmision); ?></p>
            <p class="card-text">Location: <?php echo e($car->location); ?></p>
            <p class="card-text">Color: <?php echo e($car->color); ?></p>
          </div>
        </div>
        <?php $car_count++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- About Section Start -->
    
    <!-- About Section End -->

    <!-- Services Section Start -->
    
    <!-- Services Section End -->

    <!-- Portfolio Section -->
    
    <!-- Portfolio Section Ends -->

    <!-- Why Section Start -->
    
    <!-- Why Section End -->

    <!-- Team Section Start  -->
    
    <!-- Team Section End  -->

    <!-- Start Get-Strted Section -->
    
    <!-- End Get-Strted Section -->

    <!-- Start Pricing Table Section -->
    
    <!-- End Pricing Table Section -->

    <!-- Contact Section Start -->
    <?php echo $__env->make('partials._contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Contact Section End -->

    <!-- Contact Icon Start -->
    
    <!-- Contact Icon End -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>