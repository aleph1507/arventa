</footer>
<!-- Footer Section End -->

<!-- Go To Top Link -->
<a href="#" class="back-to-top">
  <i class="fa fa-arrow-up"></i>
</a>

<div id="loader">
  <div class="cssload-thecube">
    <div class="cssload-cube cssload-c1"></div>
    <div class="cssload-cube cssload-c2"></div>
    <div class="cssload-cube cssload-c4"></div>
    <div class="cssload-cube cssload-c3"></div>
  </div>
</div>

<!-- jQuery first, then Tether, then Bootstrap JS. -->
<script src="<?php echo e(asset('js/jquery-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/tether.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/mixitup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.nav.js')); ?>"></script>
<script src="<?php echo e(asset('js/smooth-scroll.js')); ?>"></script>
<script src="<?php echo e(asset('js/smooth-on-scroll.js')); ?>"></script>
<script src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>
