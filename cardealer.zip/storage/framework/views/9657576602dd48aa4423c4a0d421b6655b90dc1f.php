<?php echo $__env->make('partials.admin._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Navigation-->
  <?php echo $__env->make('partials.admin._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('partials.admin._breadcrumbs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('partials.admin._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
