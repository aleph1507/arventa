<?php $__env->startSection('content'); ?>
  <div style="margin-top:20%; color:#666;" class="container car-gallery">
    <?php $car_count=0; $first=true; ?>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($car_count % 3 == 0): ?>
        <?php if($first == false): ?>
          </div>
        <?php endif; ?>
        <?php $first = false; ?>
        <div class="card-deck">
      <?php endif; ?>
        <div class="card car-card">
          <a class="card car-card" style="padding:0;" href="<?php echo e(route('cars.show', $car->id)); ?>">
          <img src="<?php echo e(asset('images/cars/' . $car->featuredimage)); ?>" alt="<?php echo e($car->model); ?>" class="card-img-top">
            <div class="card-body">
              <h1 class="card-title"><?php echo e($car->model); ?></h1>
              <p class="card-text">Motor Capacity: <?php echo e($car->motorcapacity); ?></p>
              <p class="card-text">Power: <?php echo e($car->power); ?></p>
              <p class="card-text">Body Type: <?php echo e($car->bodytype); ?></p>
              <p class="card-text">Gearbox Type: <?php echo e($car->gearboxtype); ?></p>
              <p class="card-text">CO2 Emmision: <?php echo e($car->co2emmision); ?></p>
              <p class="card-text">Location: <?php echo e($car->location); ?></p>
              <p class="card-text">Color: <?php echo e($car->color); ?></p>
            </div>
          </a>
        </div>
      <?php $car_count++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>